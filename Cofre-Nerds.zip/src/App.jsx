import { Routes, Route } from "react-router-dom";
import { useSelector } from "react-redux";
import { selectIsVaultOpen } from "./features/vault/vaultSlice";
import VaultDoor from "./components/VaultDoor/VaultDoor";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import CartDrawer from "./components/CartDrawer/CartDrawer";
import ToastContainer from "./components/ToastContainer/ToastContainer";
import Home from "./pages/Home";
import Favorites from "./pages/Favorites";

const App = () => {
  const isVaultOpen = useSelector(selectIsVaultOpen);

  if (!isVaultOpen) {
    return <VaultDoor />;
  }

  return (
    <div className="app-shell">
      <Header />
      <main style={{ flex: 1 }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/favoritos" element={<Favorites />} />
        </Routes>
      </main>
      <Footer />
      <CartDrawer />
      <ToastContainer />
    </div>
  );
};

export default App;
