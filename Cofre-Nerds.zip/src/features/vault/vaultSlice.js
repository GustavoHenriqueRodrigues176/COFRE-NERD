import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isOpen: false,
  isCartOpen: false
};

const vaultSlice = createSlice({
  name: "vault",
  initialState,
  reducers: {
    openVault: (state) => {
      state.isOpen = true;
    },
    openCart: (state) => {
      state.isCartOpen = true;
    },
    closeCart: (state) => {
      state.isCartOpen = false;
    },
    toggleCart: (state) => {
      state.isCartOpen = !state.isCartOpen;
    }
  }
});

export const { openVault, openCart, closeCart, toggleCart } = vaultSlice.actions;

export const selectIsVaultOpen = (state) => state.vault.isOpen;
export const selectIsCartOpen = (state) => state.vault.isCartOpen;

export default vaultSlice.reducer;
