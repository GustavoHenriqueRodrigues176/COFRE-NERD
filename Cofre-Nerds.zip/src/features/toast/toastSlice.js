import { createSlice, nanoid } from "@reduxjs/toolkit";

const initialState = {
  items: []
};

const toastSlice = createSlice({
  name: "toast",
  initialState,
  reducers: {
    addToast: {
      reducer: (state, action) => {
        state.items.push(action.payload);
      },
      prepare: (message, type = "success") => ({
        payload: { id: nanoid(), message, type }
      })
    },
    removeToast: (state, action) => {
      state.items = state.items.filter((toast) => toast.id !== action.payload);
    }
  }
});

export const { addToast, removeToast } = toastSlice.actions;

export const selectToasts = (state) => state.toast.items;

export default toastSlice.reducer;
