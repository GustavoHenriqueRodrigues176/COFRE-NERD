export const RARITY_TIERS = [
  { label: "Comum", color: "#9CA3AF", glow: "rgba(156, 163, 175, 0.55)", min: 0 },
  { label: "Incomum", color: "#22C55E", glow: "rgba(34, 197, 94, 0.55)", min: 65 },
  { label: "Raro", color: "#3B82F6", glow: "rgba(59, 130, 246, 0.55)", min: 120 },
  { label: "Épico", color: "#A855F7", glow: "rgba(168, 85, 247, 0.55)", min: 180 },
  { label: "Lendário", color: "#FBBF24", glow: "rgba(251, 191, 36, 0.65)", min: 240 }
];

export const getRarity = (baseExperience) => {
  let selected = RARITY_TIERS[0];
  RARITY_TIERS.forEach((tier) => {
    if (baseExperience >= tier.min) {
      selected = tier;
    }
  });
  return selected;
};
