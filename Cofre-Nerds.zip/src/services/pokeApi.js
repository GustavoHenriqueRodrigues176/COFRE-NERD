import axios from "axios";
import { getRarity } from "../utils/rarity";

const api = axios.create({
  baseURL: "https://pokeapi.co/api/v2"
});

const buildPrice = (baseExperience) => {
  const raw = 9.9 + baseExperience * 0.85;
  return Number(raw.toFixed(2));
};

const mapPokemonToProduct = (pokemon) => {
  const price = buildPrice(pokemon.base_experience || 50);
  return {
    id: pokemon.id,
    name: pokemon.name,
    image:
      pokemon.sprites.other?.["official-artwork"]?.front_default ||
      pokemon.sprites.front_default,
    types: pokemon.types.map((entry) => entry.type.name),
    price,
    baseExperience: pokemon.base_experience || 0,
    rarity: getRarity(pokemon.base_experience || 0),
    stats: pokemon.stats.map((entry) => ({
      name: entry.stat.name,
      value: entry.base_stat
    })),
    height: pokemon.height,
    weight: pokemon.weight
  };
};

export const fetchCollectibles = async (limit = 60) => {
  const response = await api.get(`/pokemon?limit=${limit}`);
  const requests = response.data.results.map((entry) => api.get(entry.url));
  const detailedResponses = await Promise.all(requests);
  return detailedResponses.map((detail) => mapPokemonToProduct(detail.data));
};

export default api;
