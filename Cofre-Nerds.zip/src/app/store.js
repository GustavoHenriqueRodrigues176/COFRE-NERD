import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "../features/cart/cartSlice";
import favoritesReducer from "../features/favorites/favoritesSlice";
import vaultReducer from "../features/vault/vaultSlice";
import toastReducer from "../features/toast/toastSlice";

export const store = configureStore({
  reducer: {
    cart: cartReducer,
    favorites: favoritesReducer,
    vault: vaultReducer,
    toast: toastReducer
  }
});

store.subscribe(() => {
  const state = store.getState();
  localStorage.setItem("cofre-nerd-cart", JSON.stringify(state.cart.items));
  localStorage.setItem("cofre-nerd-favorites", JSON.stringify(state.favorites.items));
});
