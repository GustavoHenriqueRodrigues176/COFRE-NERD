import { motion, AnimatePresence } from "framer-motion";
import { useDispatch, useSelector } from "react-redux";
import { X, Heart, ShoppingBag } from "lucide-react";
import { addItem } from "../../features/cart/cartSlice";
import { toggleFavorite, selectIsFavorite } from "../../features/favorites/favoritesSlice";
import { addToast } from "../../features/toast/toastSlice";
import { getTypeColor, getTypeLabel } from "../../utils/typeColors";
import "./ProductModal.css";

const STAT_LABELS = {
  hp: "HP",
  attack: "Ataque",
  defense: "Defesa",
  "special-attack": "Atq. Especial",
  "special-defense": "Def. Especial",
  speed: "Velocidade"
};

const formatPrice = (value) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const ProductModal = ({ product, onClose }) => {
  const dispatch = useDispatch();
  const isFavorite = useSelector(selectIsFavorite(product?.id));

  if (!product) return null;

  const handleAddToCart = () => {
    dispatch(addItem(product));
    dispatch(addToast(`${product.name} guardado no cofre!`, "success"));
  };

  return (
    <AnimatePresence>
      <motion.div
        className="modal-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
          className="modal-card"
          style={{ "--rarity-color": product.rarity.color }}
          initial={{ opacity: 0, scale: 0.9, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 30 }}
          transition={{ duration: 0.25 }}
          onClick={(event) => event.stopPropagation()}
        >
          <button className="modal-close" onClick={onClose}>
            <X size={20} />
          </button>

          <div className="modal-visual">
            <span className="modal-id mono">#{String(product.id).padStart(3, "0")}</span>
            <img src={product.image} alt={product.name} />
            <span className="modal-rarity mono" style={{ color: product.rarity.color }}>
              {product.rarity.label}
            </span>
          </div>

          <div className="modal-info">
            <h2 className="modal-name">{product.name}</h2>

            <div className="modal-types">
              {product.types.map((type) => (
                <span
                  key={type}
                  className="modal-type"
                  style={{ backgroundColor: getTypeColor(type) }}
                >
                  {getTypeLabel(type)}
                </span>
              ))}
            </div>

            <div className="modal-meta mono">
              <span>Altura: {(product.height / 10).toFixed(1)}m</span>
              <span>Peso: {(product.weight / 10).toFixed(1)}kg</span>
            </div>

            <div className="modal-stats">
              {product.stats.map((stat) => (
                <div className="modal-stat-row" key={stat.name}>
                  <span className="modal-stat-label mono">
                    {STAT_LABELS[stat.name] || stat.name}
                  </span>
                  <div className="modal-stat-track">
                    <motion.div
                      className="modal-stat-fill"
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, (stat.value / 180) * 100)}%` }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                    />
                  </div>
                  <span className="modal-stat-value mono">{stat.value}</span>
                </div>
              ))}
            </div>

            <div className="modal-footer">
              <span className="modal-price mono">{formatPrice(product.price)}</span>
              <div className="modal-actions">
                <button
                  className={`modal-favorite ${isFavorite ? "active" : ""}`}
                  onClick={() => dispatch(toggleFavorite(product))}
                >
                  <Heart size={18} fill={isFavorite ? "currentColor" : "none"} />
                </button>
                <button className="modal-add" onClick={handleAddToCart}>
                  <ShoppingBag size={16} />
                  Guardar no cofre
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ProductModal;
