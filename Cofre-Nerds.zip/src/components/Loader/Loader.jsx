import "./Loader.css";

const Loader = ({ label = "Escaneando o cofre..." }) => {
  return (
    <div className="loader-wrapper">
      <div className="loader-ring">
        <div className="loader-ring-inner" />
      </div>
      <p className="loader-label mono">{label}</p>
    </div>
  );
};

export default Loader;
