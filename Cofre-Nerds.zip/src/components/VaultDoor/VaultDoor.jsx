import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, Unlock } from "lucide-react";
import { useDispatch } from "react-redux";
import { openVault } from "../../features/vault/vaultSlice";
import "./VaultDoor.css";

const DIAL_NUMBERS = [12, 27, 41, 8, 33];

const VaultDoor = () => {
  const dispatch = useDispatch();
  const [unlocking, setUnlocking] = useState(false);
  const [rotation, setRotation] = useState(0);

  const handleUnlock = () => {
    if (unlocking) return;
    setUnlocking(true);
    setRotation(720);
    setTimeout(() => {
      dispatch(openVault());
    }, 1500);
  };

  return (
    <AnimatePresence>
      <motion.div
        className="vault-door-overlay"
        exit={{ opacity: 0 }}
        transition={{ duration: 0.4 }}
      >
        <motion.div
          className="vault-door-panel vault-door-left"
          animate={unlocking ? { x: "-102%" } : { x: 0 }}
          transition={{ duration: 1.1, ease: [0.65, 0, 0.35, 1], delay: 0.3 }}
        />
        <motion.div
          className="vault-door-panel vault-door-right"
          animate={unlocking ? { x: "102%" } : { x: 0 }}
          transition={{ duration: 1.1, ease: [0.65, 0, 0.35, 1], delay: 0.3 }}
        />
        <div className="vault-door-content">
          <p className="vault-door-eyebrow mono">SISTEMA DE SEGURANÇA COFRE NERD</p>
          <h1 className="vault-door-title">O Cofre Nerd</h1>
          <p className="vault-door-subtitle">
            Cartas Pokémon raras trancadas a sete chaves. Gire a fechadura para
            entrar na coleção.
          </p>
          <motion.button
            className="vault-dial"
            onClick={handleUnlock}
            animate={{ rotate: rotation }}
            transition={{ duration: 1.4, ease: "easeInOut" }}
            disabled={unlocking}
          >
            <div className="vault-dial-ring">
              {DIAL_NUMBERS.map((number, index) => (
                <span
                  key={number}
                  className="vault-dial-number mono"
                  style={{ transform: `rotate(${index * 72}deg) translateY(-92px)` }}
                >
                  {number}
                </span>
              ))}
            </div>
            <div className="vault-dial-core">
              {unlocking ? <Unlock size={30} /> : <Lock size={30} />}
            </div>
          </motion.button>
          <button className="vault-enter-button" onClick={handleUnlock} disabled={unlocking}>
            {unlocking ? "Destravando..." : "Abrir o Cofre"}
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default VaultDoor;
