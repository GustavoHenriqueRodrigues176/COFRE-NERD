import { NavLink } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { ShieldHalf, Heart, Vault } from "lucide-react";
import { selectCartCount, selectCartTotal } from "../../features/cart/cartSlice";
import { selectFavorites } from "../../features/favorites/favoritesSlice";
import { toggleCart } from "../../features/vault/vaultSlice";
import "./Header.css";

const formatPrice = (value) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const Header = () => {
  const dispatch = useDispatch();
  const cartCount = useSelector(selectCartCount);
  const cartTotal = useSelector(selectCartTotal);
  const favorites = useSelector(selectFavorites);

  return (
    <header className="app-header">
      <div className="container app-header-inner">
        <NavLink to="/" className="app-logo">
          <ShieldHalf size={26} className="app-logo-icon" />
          <span>
            Cofre <strong>Nerd</strong>
          </span>
        </NavLink>

        <nav className="app-nav">
          <NavLink to="/" end className="app-nav-link">
            Loja
          </NavLink>
          <NavLink to="/favoritos" className="app-nav-link">
            <Heart size={16} />
            Favoritos
            {favorites.length > 0 && (
              <span className="app-nav-badge mono">{favorites.length}</span>
            )}
          </NavLink>
        </nav>

        <button className="cart-trigger" onClick={() => dispatch(toggleCart())}>
          <Vault size={20} />
          <span className="cart-trigger-total mono">{formatPrice(cartTotal)}</span>
          {cartCount > 0 && <span className="cart-trigger-badge mono">{cartCount}</span>}
        </button>
      </div>
    </header>
  );
};

export default Header;
