import { PackageSearch } from "lucide-react";
import "./EmptyState.css";

const EmptyState = ({ title, description }) => {
  return (
    <div className="empty-state">
      <PackageSearch size={40} />
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  );
};

export default EmptyState;
