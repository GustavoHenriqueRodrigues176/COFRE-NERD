import { ShieldHalf } from "lucide-react";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="app-footer">
      <div className="container app-footer-inner">
        <div className="app-footer-brand">
          <ShieldHalf size={18} />
          <span>Cofre Nerd</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
