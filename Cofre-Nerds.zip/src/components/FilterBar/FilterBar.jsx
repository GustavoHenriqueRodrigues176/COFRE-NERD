import { Search } from "lucide-react";
import { getTypeColor, getTypeLabel } from "../../utils/typeColors";
import "./FilterBar.css";

const FilterBar = ({
  search,
  onSearchChange,
  types,
  activeType,
  onTypeChange,
  sortOrder,
  onSortChange
}) => {
  return (
    <div className="filter-bar">
      <div className="filter-search">
        <Search size={18} />
        <input
          type="text"
          placeholder="Buscar carta na coleção..."
          value={search}
          onChange={(event) => onSearchChange(event.target.value)}
        />
      </div>

      <div className="filter-types">
        <button
          className={`filter-type-chip ${activeType === "all" ? "active" : ""}`}
          onClick={() => onTypeChange("all")}
        >
          Todos
        </button>
        {types.map((type) => (
          <button
            key={type}
            className={`filter-type-chip ${activeType === type ? "active" : ""}`}
            style={{
              "--chip-color": getTypeColor(type),
              borderColor: activeType === type ? getTypeColor(type) : undefined
            }}
            onClick={() => onTypeChange(type)}
          >
            {getTypeLabel(type)}
          </button>
        ))}
      </div>

      <select
        className="filter-sort mono"
        value={sortOrder}
        onChange={(event) => onSortChange(event.target.value)}
      >
        <option value="default">Ordenar por</option>
        <option value="price-asc">Preço: menor primeiro</option>
        <option value="price-desc">Preço: maior primeiro</option>
        <option value="rarity-desc">Raridade: maior primeiro</option>
        <option value="name-asc">Nome: A-Z</option>
      </select>
    </div>
  );
};

export default FilterBar;
