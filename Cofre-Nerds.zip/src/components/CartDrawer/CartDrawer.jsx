import { motion, AnimatePresence } from "framer-motion";
import { useDispatch, useSelector } from "react-redux";
import { X, Minus, Plus, Trash2, Vault } from "lucide-react";
import {
  selectCartItems,
  selectCartTotal,
  incrementQuantity,
  decrementQuantity,
  removeItem,
  clearCart
} from "../../features/cart/cartSlice";
import { closeCart, selectIsCartOpen } from "../../features/vault/vaultSlice";
import { addToast } from "../../features/toast/toastSlice";
import "./CartDrawer.css";

const formatPrice = (value) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const CartDrawer = () => {
  const dispatch = useDispatch();
  const isOpen = useSelector(selectIsCartOpen);
  const items = useSelector(selectCartItems);
  const total = useSelector(selectCartTotal);

  const handleCheckout = () => {
    dispatch(clearCart());
    dispatch(closeCart());
    dispatch(addToast("Compra confirmada! Suas cartas chegam em breve.", "success"));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="drawer-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => dispatch(closeCart())}
          />
          <motion.aside
            className="cart-drawer"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.35, ease: [0.65, 0, 0.35, 1] }}
          >
            <div className="cart-drawer-header">
              <h3>
                <Vault size={20} /> Seu Cofre
              </h3>
              <button onClick={() => dispatch(closeCart())}>
                <X size={20} />
              </button>
            </div>

            {items.length === 0 ? (
              <div className="cart-empty">
                <p>Seu cofre está vazio.</p>
                <span>Adicione cartas raras para começar sua coleção.</span>
              </div>
            ) : (
              <div className="cart-items">
                {items.map((item) => (
                  <div className="cart-item" key={item.id}>
                    <img src={item.image} alt={item.name} />
                    <div className="cart-item-info">
                      <p className="cart-item-name">{item.name}</p>
                      <span className="cart-item-price mono">{formatPrice(item.price)}</span>
                      <div className="cart-item-controls">
                        <button onClick={() => dispatch(decrementQuantity(item.id))}>
                          <Minus size={14} />
                        </button>
                        <span className="mono">{item.quantity}</span>
                        <button onClick={() => dispatch(incrementQuantity(item.id))}>
                          <Plus size={14} />
                        </button>
                      </div>
                    </div>
                    <button
                      className="cart-item-remove"
                      onClick={() => dispatch(removeItem(item.id))}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="cart-drawer-footer">
              <div className="cart-total-row">
                <span>Total</span>
                <span className="mono">{formatPrice(total)}</span>
              </div>
              <button
                className="cart-checkout"
                onClick={handleCheckout}
                disabled={items.length === 0}
              >
                Fechar o Cofre
              </button>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartDrawer;
