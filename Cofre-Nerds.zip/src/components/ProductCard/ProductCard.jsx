import { useDispatch, useSelector } from "react-redux";
import { Heart, Plus } from "lucide-react";
import { motion } from "framer-motion";
import { addItem } from "../../features/cart/cartSlice";
import { toggleFavorite, selectIsFavorite } from "../../features/favorites/favoritesSlice";
import { addToast } from "../../features/toast/toastSlice";
import { getTypeColor, getTypeLabel } from "../../utils/typeColors";
import "./ProductCard.css";

const formatPrice = (value) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const ProductCard = ({ product, onOpenDetails }) => {
  const dispatch = useDispatch();
  const isFavorite = useSelector(selectIsFavorite(product.id));

  const handleAddToCart = (event) => {
    event.stopPropagation();
    dispatch(addItem(product));
    dispatch(addToast(`${product.name} guardado no cofre!`, "success"));
  };

  const handleToggleFavorite = (event) => {
    event.stopPropagation();
    dispatch(toggleFavorite(product));
  };

  return (
    <motion.article
      className="product-card"
      style={{ "--rarity-color": product.rarity.color, "--rarity-glow": product.rarity.glow }}
      whileHover={{ y: -6 }}
      onClick={() => onOpenDetails(product)}
    >
      <div className="product-card-top">
        <span className="product-card-id mono">#{String(product.id).padStart(3, "0")}</span>
        <span className="product-card-rarity mono" style={{ color: product.rarity.color }}>
          {product.rarity.label}
        </span>
      </div>

      <div className="product-card-screen">
        <img src={product.image} alt={product.name} loading="lazy" />
      </div>

      <h3 className="product-card-name">{product.name}</h3>

      <div className="product-card-types">
        {product.types.map((type) => (
          <span
            key={type}
            className="product-card-type"
            style={{ backgroundColor: getTypeColor(type) }}
          >
            {getTypeLabel(type)}
          </span>
        ))}
      </div>

      <div className="product-card-footer">
        <span className="product-card-price mono">{formatPrice(product.price)}</span>
        <div className="product-card-actions">
          <button
            className={`product-card-favorite ${isFavorite ? "active" : ""}`}
            onClick={handleToggleFavorite}
          >
            <Heart size={16} fill={isFavorite ? "currentColor" : "none"} />
          </button>
          <button className="product-card-add" onClick={handleAddToCart}>
            <Plus size={16} />
          </button>
        </div>
      </div>
    </motion.article>
  );
};

export default ProductCard;
