import { ShieldAlert } from "lucide-react";
import "./ErrorMessage.css";

const ErrorMessage = ({ message, onRetry }) => {
  return (
    <div className="error-panel">
      <ShieldAlert size={34} className="error-icon" />
      <h3>Falha no acesso ao cofre</h3>
      <p>{message}</p>
      {onRetry && (
        <button className="error-retry" onClick={onRetry}>
          Tentar novamente
        </button>
      )}
    </div>
  );
};

export default ErrorMessage;
