import { useState } from "react";
import { useSelector } from "react-redux";
import { selectFavorites } from "../features/favorites/favoritesSlice";
import ProductCard from "../components/ProductCard/ProductCard";
import ProductModal from "../components/ProductModal/ProductModal";
import EmptyState from "../components/EmptyState/EmptyState";

const Favorites = () => {
  const favorites = useSelector(selectFavorites);
  const [selectedProduct, setSelectedProduct] = useState(null);

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 40 }}>
      <section className="page-hero">
        <p className="page-hero-eyebrow mono">SALA VIP</p>
        <h1>Suas cartas favoritas</h1>
        <p className="page-hero-subtitle">
          As raridades que você marcou para guardar de olho antes de decidir a
          compra.
        </p>
      </section>

      {favorites.length === 0 ? (
        <EmptyState
          title="Nenhum favorito ainda"
          description="Toque no coração de uma carta na loja para guardá-la aqui."
        />
      ) : (
        <div className="product-grid">
          {favorites.map((product) => (
            <ProductCard key={product.id} product={product} onOpenDetails={setSelectedProduct} />
          ))}
        </div>
      )}

      <ProductModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />
    </div>
  );
};

export default Favorites;
