import { useEffect, useMemo, useState } from "react";
import { fetchCollectibles } from "../services/pokeApi";
import { useDebounce } from "../hooks/useDebounce";
import Loader from "../components/Loader/Loader";
import ErrorMessage from "../components/ErrorMessage/ErrorMessage";
import FilterBar from "../components/FilterBar/FilterBar";
import ProductCard from "../components/ProductCard/ProductCard";
import ProductModal from "../components/ProductModal/ProductModal";
import EmptyState from "../components/EmptyState/EmptyState";

const Home = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [activeType, setActiveType] = useState("all");
  const [sortOrder, setSortOrder] = useState("default");
  const [selectedProduct, setSelectedProduct] = useState(null);

  const debouncedSearch = useDebounce(search);

  const loadProducts = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchCollectibles(60);
      setProducts(data);
    } catch (requestError) {
      setError("Não foi possível carregar as cartas do servidor. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const availableTypes = useMemo(() => {
    const typeSet = new Set();
    products.forEach((product) => product.types.forEach((type) => typeSet.add(type)));
    return Array.from(typeSet).sort();
  }, [products]);

  const filteredProducts = useMemo(() => {
    let list = [...products];

    if (debouncedSearch.trim()) {
      list = list.filter((product) =>
        product.name.toLowerCase().includes(debouncedSearch.toLowerCase())
      );
    }

    if (activeType !== "all") {
      list = list.filter((product) => product.types.includes(activeType));
    }

    switch (sortOrder) {
      case "price-asc":
        list.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list.sort((a, b) => b.price - a.price);
        break;
      case "rarity-desc":
        list.sort((a, b) => b.baseExperience - a.baseExperience);
        break;
      case "name-asc":
        list.sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        break;
    }

    return list;
  }, [products, debouncedSearch, activeType, sortOrder]);

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 40 }}>
      <section className="page-hero">
        <p className="page-hero-eyebrow mono">COLEÇÃO OFICIAL</p>
        <h1>Cartas trancadas, prontas para o seu deck</h1>
        <p className="page-hero-subtitle">
          Explore criaturas raras direto da PokéAPI, cada uma com seu nível de
          raridade e valor de mercado do cofre.
        </p>
      </section>

      {loading && <Loader />}

      {!loading && error && <ErrorMessage message={error} onRetry={loadProducts} />}

      {!loading && !error && (
        <>
          <FilterBar
            search={search}
            onSearchChange={setSearch}
            types={availableTypes}
            activeType={activeType}
            onTypeChange={setActiveType}
            sortOrder={sortOrder}
            onSortChange={setSortOrder}
          />

          {filteredProducts.length === 0 ? (
            <EmptyState
              title="Nenhuma carta encontrada"
              description="Ajuste sua busca ou remova os filtros de tipo para ver mais itens do cofre."
            />
          ) : (
            <div className="product-grid">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onOpenDetails={setSelectedProduct}
                />
              ))}
            </div>
          )}
        </>
      )}

      <ProductModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />
    </div>
  );
};

export default Home;
