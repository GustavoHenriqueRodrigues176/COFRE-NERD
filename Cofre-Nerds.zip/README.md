# Cofre Nerd

E-commerce de cartas Pokémon construído em React, com tema visual de cofre
bancário e Pokédex. Os dados dos produtos vêm da PokéAPI.

## Tecnologias

- React + Vite
- Redux Toolkit / React Redux
- Axios
- React Router DOM
- Framer Motion
- Lucide React

## Como rodar

```bash
npm install
npm run dev
```

Abra o endereço mostrado no terminal (geralmente http://localhost:5173).

## Funcionalidades

- Tela de entrada em formato de porta de cofre com animação de destravamento
- Listagem de cartas consumindo a PokéAPI via Axios, com loading e tratamento de erro
- Busca por nome com debounce, filtro por tipo e ordenação por preço/raridade
- Ficha detalhada de cada carta em estilo Pokédex, com barras de status animadas
- Carrinho de compras global via Redux Toolkit, persistido no localStorage
- Sistema de favoritos com página própria
- Notificações (toasts) ao adicionar itens ao cofre
- Layout responsivo para desktop e mobile
